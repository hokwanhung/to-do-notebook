public class Player {
	boolean isAlive;
	int balance;
	int position;
}
