
public class Land extends Slot {

	boolean isGO;
	int ownerID;
	int landPrice;
	String name;

}
