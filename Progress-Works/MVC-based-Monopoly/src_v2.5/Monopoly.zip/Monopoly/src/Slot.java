import java.util.ArrayList;

public class Slot {
	ArrayList<Integer> playerOnSlot = new ArrayList();
	boolean isLand = false;
}
